<!-- Preloader Start -->
<div class="sigma_preloader">
        <img src="assets/img/christian.svg" alt="preloader">
    </div>
    <!-- Preloader End -->